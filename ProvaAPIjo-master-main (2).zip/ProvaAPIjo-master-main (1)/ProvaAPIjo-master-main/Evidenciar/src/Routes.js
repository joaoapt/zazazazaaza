import { BrowserRouter, Routes, Route } from "react-router-dom";

import Login from './pages/login'
import Consulta from './pages/consulta'
export default function Index() {
    return(
        <BrowserRouter>
            <Routes>
                <Route path="/" element={<Login />}/>
                <Route path="/consulta" element={<Consulta />}/>
            </Routes>
        </BrowserRouter>
    )
}