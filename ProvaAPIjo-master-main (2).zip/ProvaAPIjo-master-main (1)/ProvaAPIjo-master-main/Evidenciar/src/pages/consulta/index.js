
import '/index.scss'

export default function Index() {
    return(
        <main className='consu'>
            <div>

                <div>
                    <input type="text" placeholder='Buscar filmes por nome' />
                    <img src='./img/icon-buscar.svg' alt='buscar' />
                </div>

                <table>
                    <thead>
                        <tr>
                            <th>Identificação</th>
                            <th>anime</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td></td>
                            <td></td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <br/><br/>
        </main>
    )
}