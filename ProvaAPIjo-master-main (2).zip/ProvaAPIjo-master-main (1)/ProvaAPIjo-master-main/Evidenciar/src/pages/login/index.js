import './index.scss'

export default function Index() {
    
    return(
        <main className='login'>
                  <div>
                    <div className=''>
                        <label>E-mail:</label>
                        <input type='text' placeholder='Informe seu e-mail' value={email} onChange={e => setEmail(e.target.value)}/>
                    </div>
                    <div className=''>
                        <label>Senha:</label>
                        <input type='password' placeholder='***' value={senha} onChange={e => setSenha(e.target.value)} />
                    </div>
                    <div className=''>
                        <button className='' onClick={entrarClick} disabled={carregando} >ENTRAR</button> 
                    </div>
                    <div className='form-entrar invalido'>
                        {erro}
                    </div>
                </div>
        </main>
    )
}